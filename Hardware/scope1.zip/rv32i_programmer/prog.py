import time
import serial
from tqdm import tqdm

PAGE_SIZE = 256

ser = serial.Serial('COM3', 115200)

def sync():
	sync = b''
	while not b'sync' in sync:
		sync = ser.read(8)

def main():
	a = bytearray(PAGE_SIZE + 1)
	a[0:256] = [15] * 256
	a[-1] = ord('\n')
	a = bytes(a)

	sync()
	ser.write(a)
	print(a)

	sync()
	ret = ser.read_until(b'\n')
	print(ret)

	ser.close()

if __name__ == '__main__':
	main()
